
## SIP PIUTANG
This project is laravel based, how to use this repository:
1. Clone this project to your local repository
2. Run "php artisan serve" to activate the server
3. Run "php artisan migrate" to migrating database
4. Don't forget to change database name in .env file

