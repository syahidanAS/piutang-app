<?php $__env->startSection('title', 'Jurnal'); ?>

<?php $__env->startSection('breadcrumbs'); ?>
<div class="breadcrumbs">
    <div class="col-sm-4">
        <div class="page-header float-left">
            <div class="page-title">
                <h1>Jurnal</h1>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card mx-2">
	<div class="card-body">
	  <h5 class="card-title">Jurnal</h5>

      <div style="float:left;">
        <form action="/jurnal-after-search" method="POST">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col">
                    <input class="form-control" type="date" id="from" onchange="getFrom()" name="from" required>
                </div>
                -
                <div class="col">
                    <input class="form-control" type="date" id="to" onchange="getTo()"  name="to"required>
                </div>
                <div class="col">
                    <button class="btn btn-info " type="submit"><i class="fa fa-search" onclick="search()"></i> Filter</button>
                </div>
              </div>


            
        </form>
      </div>

      <div style="float:left; margin-left:5px;">
        
        <form onclick="alert('Sebentar ya masih dimasak :)')">
            <?php echo csrf_field(); ?>
            <input class="" type="text" id="from-text" name="tahun" hidden  required>
            <input class="" type="text" id="to-text" name="tahun" hidden  required>
            <button class="btn btn-success" type="submit"><i class="fa fa-print" onclick="search()"></i> Cetak</button>
        </form>
      </div>


	</div>
  </div>
  <?php if(count($dataJurnal) <= 0): ?>
  <div class="card mx-2">
	<div class="card-header">
		
	</div>
	<div class="card-body text-center">
       
	</div>
  </div>


  <?php else: ?>
  <div class="card mx-2">
	<div class="card-header">
		<h4 id="periodeValue"></h4>
	</div>
	<div class="card-body">
    <table class="w-100">
      <thead>
          <tr class="text-center">
              <th>No. Jurnal</th>
              <th>Tanggal Jurnal</th>
              <th>Keterangan</th>
              <th>Kode Perkiraan</th>
              <th>Nama Perkiraan</th>
              <th>Debet</th>
              <th>Kredit</th>
          </tr>
      </thead>
      <tbody>
        <?php $debet_1=0 ?>
        <?php $debet_2=0 ?>
        <?php $kredit_1=0 ?>
        <?php $kredit_2=0 ?>
          <?php $__currentLoopData = $dataJurnal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
              <?php if($key == 0 || $key % 2 == 0): ?>
              <td class="text-center" rowspan="2"><?php echo e($item->no_jurnal); ?></td>
              <td class="text-center" rowspan="2"><?php echo e($item->tanggal->isoFormat('D MMMM Y')); ?></td>
              <td rowspan="2"><?php echo e($item->keterangan); ?></td>
              <?php endif; ?>
              <td class="text-center" style="border-bottom-style:none;"><?php echo e($item->kode_perkiraan); ?></td>
              <td class="text-center"><?php echo e($item->nama_perkiraan); ?></td>
              <?php if($item->flag == "piutang-pendapatan"): ?>
              <td class="text-center" style="border-bottom-style:none;">Rp. <?php echo number_format($item->nominal,0,',','.'); ?></td>
              <td class="text-center">-</td>
              <?php $debet_1 += $item->nominal  ?>
              <?php elseif($item->flag == "pendapatan-piutang"): ?>
              <td class="text-center" style="border-bottom-style:none;">-</td>
              <td class="text-center">Rp. <?php echo number_format($item->nominal,0,',','.'); ?></td>
              <?php $kredit_1 += $item->nominal  ?>
              <?php elseif($item->flag == "kas-piutang"): ?>
              <td class="text-center" style="border-bottom-style:none;">Rp. <?php echo number_format($item->nominal,0,',','.'); ?></td>
              <td class="text-center">-</td>
              <?php $debet_2 += $item->nominal  ?>
              <?php elseif($item->flag == "piutang-kas"): ?>
              <td class="text-center" style="border-bottom-style:none;">-</td>
              <td class="text-center">Rp. <?php echo number_format($item->nominal,0,',','.'); ?></td>
              <?php $kredit_2 += $item->nominal  ?>
              <?php endif; ?>
          </tr>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td class="text-center" colspan="5"><b>TOTAL</b></td>
            <td class="text-center"><b>Rp. <?php echo number_format($debet_1+$debet_2,0,',','.'); ?></b></td>
            <td class="text-center"><b>Rp. <?php echo number_format($kredit_1+$kredit_2,0,',','.'); ?></b></td>
          </tr>
      </tbody>
     </table>
  </div>
  <?php endif; ?>
  <script>
    function getFrom(){
        let yearPeriode = document.getElementById("from").value;
        document.getElementById("from-text").value = yearPeriode;
    }
    function getTo(){
        let yearPeriode = document.getElementById("to").value;
        document.getElementById("to-text").value = yearPeriode;
    }

  </script>
  <style>
	table, th, td {
        border: 1px solid black;
        border-collapse: collapse;

    }
  </style>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\syahi\Documents\dev\piutang-app\resources\views/jurnal/index.blade.php ENDPATH**/ ?>