<div class="card-body">
    <?php $sum_nominal_piutang = 0 ?>
    <?php $column_five_percent = 0 ?>
    <?php $column_ten_percent = 0 ?>
    <?php $column_fifty_percent = 0 ?>
    <?php $column_hundred_percent = 0 ?>
    <?php $column_grand_total = 0 ?>
    <table id="age-table" style="text-align: center;">
        <thead>
            <tr>
                <th>No</th>
                <th>No. Invoice</th>
                <th>Debitur</th>
                <th>Nominal Piutang</th>
                <th>Umur Piutang (Hari)</th>
                <th>0-30 Hari (5%)</th>
                <th>31-60 Hari (10%)</th>
                <th>61-90 Hari (50%)</th>
                <th>>90 Hari (100%)</th>
                <th>Jumlah Penyusutan</th>
            </tr>
        </thead>
            <?php $__currentLoopData = $umur; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <tbody>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($item->no_invoice); ?></td>
                <td><?php echo e($item->nm_debitur); ?></td>
                <td>Rp. <?php echo number_format($item->nominal_piutang,0,',','.'); ?></td>
                <td><?php echo e($item->umur_piutang); ?></td>
                <?php if($item->umur_piutang >= 0 && $item->umur_piutang <= 30): ?>
                <td>Rp. <?php echo number_format($item->hasil_persentase,0,',','.'); ?></td>
                <td></td>
                <td></td>
                <td></td>
                <?php $column_five_percent += $item->hasil_persentase  ?>
                <td>Rp. <?php echo number_format($item->hasil_persentase,0,',','.'); ?></td>
                <?php elseif($item->umur_piutang >= 30 && $item->umur_piutang <= 60): ?>
                <td></td>
                <td>Rp. <?php echo number_format($item->hasil_persentase,0,',','.'); ?></td>
                <td></td>
                <td></td>
                <td>Rp. <?php echo number_format($item->hasil_persentase,0,',','.'); ?></td>
                <?php $column_ten_percent += $item->hasil_persentase  ?>
                <?php elseif($item->umur_piutang >= 60 && $item->umur_piutang <= 90): ?>
                <td></td>
                <td></td>
                <td>Rp. <?php echo number_format($item->hasil_persentase,0,',','.'); ?></td>
                <td></td>
                <td></td>
                <td>Rp. <?php echo number_format($item->hasil_persentase,0,',','.'); ?></td>
                <?php $column_fifty_percent += $item->hasil_persentase  ?>
                <?php elseif($item->umur_piutang >= 90): ?>
                <td></td>
                <td></td>
                <td></td>
                <td>Rp. <?php echo number_format($item->hasil_persentase,0,',','.'); ?></td>
                <td>Rp. <?php echo number_format($item->hasil_persentase,0,',','.'); ?></td>
                <?php $column_hundred_percent += $item->hasil_persentase  ?>
                <?php endif; ?>
            </tr>
           </tbody>
            <?php $sum_nominal_piutang += $item->nominal_piutang  ?>
            <?php $column_grand_total += $item->hasil_persentase  ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <tr>
                <th colspan="3">TOTAL</th>
                <th>Rp. <?php echo number_format($sum_nominal_piutang,0,',','.'); ?></th>
                <th></th>
                <th>Rp. <?php echo number_format($column_five_percent,0,',','.'); ?></th>
                <th>Rp. <?php echo number_format($column_ten_percent,0,',','.'); ?></th>
                <th>Rp. <?php echo number_format($column_fifty_percent,0,',','.'); ?></th>
                <th>Rp. <?php echo number_format($column_hundred_percent,0,',','.'); ?></th>
                <th>Rp. <?php echo number_format($column_grand_total,0,',','.'); ?></th>
            </tr>
    </table>
</div>
<div style="margin-top: 20px; font-size:1.1rem; text-align:right; border-style:solid; margin-left:56%; padding-top:5px; padding-bottom:5px; padding-right:5px;">
    TOTAL CADANGAN KERUGIAN PIUTANG: Rp. <?php echo number_format($column_grand_total,0,',','.'); ?>
</div>
<style>
	table, th, td {
        border: 1px solid black;
        border-collapse: collapse;
    }
  </style>
<?php /**PATH C:\Users\syahi\Documents\dev\piutang-app\resources\views/pdf/umur.blade.php ENDPATH**/ ?>