

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('breadcrumbs'); ?>
<div class="breadcrumbs">
    <div class="col-sm-4">
        <div class="page-header float-left">
            <div class="page-title">
                <h1>Dashboard</h1>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="sufee-login d-flex align-content-center flex-wrap">
    <div class="container text-center" style="margin-top: 7%;">
        <img src="<?php echo e(asset('images/hospital-logo.png')); ?>" alt="" style="width: 200px;">
    </div>
</div>
<div class="sufee-login d-flex align-content-center flex-wrap">
    <div class="container mt-4" style="margin-left: 19%;">
        <div class="col-md-3">
            <div class="card" style="border-radius: 0px 30px 0px 0px;  border: 1px solid #000000;">
                <div class="card-body">
                    <strong class="card-title">Rp 1.000.000</strong>
                </div>
                <div class="card-footer text-center" >
                    <strong>Total Piutang</strong>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card" style="border-radius: 0px 30px 0px 0px; border: 1px solid #000000;">
                <div class="card-body">
                    <strong class="card-title">Rp 1.000.000</strong>
                </div>
                <div class="card-footer text-center">
                    <strong>Realisasi Piutang</strong>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card" style="border-radius: 0px 30px 0px 0px; border: 1px solid #000000;">
                <div class="card-body">
                    <strong class="card-title">Rp 1.000.000</strong>
                </div>
                <div class="card-footer text-center">
                    <strong>Sisa Piutang</strong>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\syahi\Documents\dev\piutang-app\resources\views/dashboard/index.blade.php ENDPATH**/ ?>